#include "launcher_core.h"

#include <algorithm>
#include <cctype>
#include <cstdio>
#include <map>
#include <string>

#include <volk.h>

namespace wwe13::launcher {
namespace {

std::string DeviceId(uint32_t vendor, uint32_t device) {
  char buffer[32]{};
  std::snprintf(buffer, sizeof(buffer), "%04X:%04X", vendor, device);
  return buffer;
}

std::string Lower(std::string value) {
  std::transform(value.begin(), value.end(), value.begin(), [](unsigned char ch) {
    return static_cast<char>(std::tolower(ch));
  });
  return value;
}

}  // namespace

std::vector<GpuInfo> ListGpus() {
  std::vector<GpuInfo> result;
  if (volkInitialize() != VK_SUCCESS) return result;

  VkApplicationInfo application{};
  application.sType = VK_STRUCTURE_TYPE_APPLICATION_INFO;
  application.pApplicationName = "WWE '13 PC Recompiled Launcher";
  application.applicationVersion = 1;
  application.pEngineName = "WWE '13 PC Recompiled Launcher";
  application.engineVersion = 1;
  application.apiVersion = VK_API_VERSION_1_0;
  VkInstanceCreateInfo create_info{};
  create_info.sType = VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO;
  create_info.pApplicationInfo = &application;

  VkInstance instance = VK_NULL_HANDLE;
  if (vkCreateInstance(&create_info, nullptr, &instance) != VK_SUCCESS || instance == VK_NULL_HANDLE) {
    volkFinalize();
    return result;
  }
  volkLoadInstance(instance);

  uint32_t device_count = 0;
  VkResult enumerate_result = vkEnumeratePhysicalDevices(instance, &device_count, nullptr);
  if (enumerate_result == VK_SUCCESS && device_count != 0) {
    std::vector<VkPhysicalDevice> devices(device_count);
    enumerate_result = vkEnumeratePhysicalDevices(instance, &device_count, devices.data());
    if (enumerate_result == VK_SUCCESS || enumerate_result == VK_INCOMPLETE) {
      devices.resize(device_count);
      std::map<std::string, unsigned> identity_counts;
      for (size_t index = 0; index < devices.size(); ++index) {
        const VkPhysicalDevice device = devices[index];
        VkPhysicalDeviceProperties properties{};
        vkGetPhysicalDeviceProperties(device, &properties);
        if (properties.deviceType == VK_PHYSICAL_DEVICE_TYPE_CPU) continue;
        const std::string name = properties.deviceName[0] ? properties.deviceName : "Vulkan GPU";
        const std::string lowered = Lower(name);
        if (lowered.find("llvmpipe") != std::string::npos ||
            lowered.find("lavapipe") != std::string::npos ||
            lowered.find("software rasterizer") != std::string::npos) {
          continue;
        }
        const std::string identity = DeviceId(properties.vendorID, properties.deviceID);
        ++identity_counts[identity];
        result.push_back({identity, name,
                          properties.deviceType == VK_PHYSICAL_DEVICE_TYPE_INTEGRATED_GPU,
                          static_cast<int>(index)});
      }
      for (auto& gpu : result) {
        if (identity_counts[gpu.id] > 1) gpu.id += ":" + std::to_string(gpu.vulkan_index);
      }
    }
  }

  vkDestroyInstance(instance, nullptr);
  volkFinalize();
  return result;
}

Recommendation RecommendedSettings(const std::vector<GpuInfo>& gpus) {
  Recommendation recommendation;
  recommendation.settings.resolution = Resolution::k720p;
  recommendation.settings.frame_rate = FrameRate::kClassic;
  recommendation.settings.anti_aliasing = AntiAliasing::kOriginal4x;
  recommendation.settings.explicit_choice = false;
  const auto discrete = std::find_if(gpus.begin(), gpus.end(), [](const GpuInfo& gpu) {
    return !gpu.integrated;
  });
  if (discrete != gpus.end()) {
    recommendation.reason = discrete->name + " - discrete graphics";
    // Radeon RX 470/480/570/580/590 (Polaris 10/20, device 67DF): 1080p is comfortable for this
    // card; frame pacing is limited by the CPU (4-core Ivy Bridge), not the picture size, so keep
    // Classic pacing and the original 4x AA.
    if (discrete->id.rfind("1002:67DF", 0) == 0 ||
        discrete->name.find("RX 580") != std::string::npos ||
        discrete->name.find("RX 480") != std::string::npos ||
        discrete->name.find("RX 570") != std::string::npos ||
        discrete->name.find("RX 470") != std::string::npos ||
        discrete->name.find("RX 590") != std::string::npos) {
      recommendation.settings.resolution = Resolution::k1080p;
      recommendation.reason = discrete->name + " - discrete graphics, 1080p";
    }
  } else if (!gpus.empty()) {
    recommendation.settings.resolution = Resolution::k480p;
    recommendation.settings.frame_rate = FrameRate::kLock30;
    recommendation.reason = gpus.front().name + " - integrated graphics";
  } else {
    recommendation.reason = "Automatic graphics settings";
  }
  return recommendation;
}

}  // namespace wwe13::launcher
