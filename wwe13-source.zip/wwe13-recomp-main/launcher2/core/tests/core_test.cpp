#ifdef NDEBUG
#undef NDEBUG
#endif

#include "launcher_core.h"

#include "internal/archive.h"
#include "internal/util.h"

#include <cassert>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <filesystem>
#include <iterator>
#include <fstream>
#include <iostream>
#include <string>
#include <vector>

namespace fs = std::filesystem;
using namespace wwe13::launcher;

namespace {

void Put16(std::ostream& output, uint16_t value) {
  output.put(static_cast<char>(value & 0xFF));
  output.put(static_cast<char>(value >> 8));
}

void Put32(std::ostream& output, uint32_t value) {
  Put16(output, static_cast<uint16_t>(value));
  Put16(output, static_cast<uint16_t>(value >> 16));
}

void WriteShortWav(const fs::path& file) {
  constexpr uint32_t rate = 8000;
  constexpr uint32_t frames = 2000;
  constexpr uint32_t data_bytes = frames * 2;
  std::ofstream output(file, std::ios::binary | std::ios::trunc);
  output.write("RIFF", 4);
  Put32(output, 36 + data_bytes);
  output.write("WAVEfmt ", 8);
  Put32(output, 16);
  Put16(output, 1);
  Put16(output, 1);
  Put32(output, rate);
  Put32(output, rate * 2);
  Put16(output, 2);
  Put16(output, 16);
  output.write("data", 4);
  Put32(output, data_bytes);
  for (uint32_t frame = 0; frame < frames; ++frame) {
    const int16_t sample = static_cast<int16_t>(std::sin(frame * 2.0 * 3.141592653589793 * 440.0 / rate) * 10000.0);
    Put16(output, static_cast<uint16_t>(sample));
  }
  output.flush();
  assert(output.good());
}

Paths MakePaths(const fs::path& root) {
  Paths paths = ResolvePaths(root / "launcher");
  paths.exe_dir = root;
  paths.game_exe = root / "wwe13";
  paths.settings_file = root / "wwe13-enhanced.ini";
  paths.userdata_dir = root / "userdata";
  paths.music_dir = root / "music";
  paths.logs_dir = root / "logs";
  paths.backups_dir = root / "backups";
  paths.default_game_folder = root / "WWE 13";
  return paths;
}

void TestSettings(const fs::path& root) {
  const fs::path directory = root / "settings";
  fs::create_directories(directory);
  Paths paths = MakePaths(directory);
  const std::string ini =
      "[Settings]\r\nschema=7\r\nanti_aliasing=2x\r\nresolution=1440p\r\n"
      "frame_rate=lock-30\r\ndisplay=windowed\r\ngpu=10de:2684\r\n"
      "game_folder=C:/Games/Roster-\xC3\xA9\r\nauto_start=1\r\n"
      "auto_backup=0\r\nunknown_key=keep-this\r\ngpu_name=Old GPU\r\n\r\n[Other]\r\nkeep=also-this\r\n";
  const auto ini_bytes = wwe13::launcher::internal::Utf8ToUtf16LeBytes(ini);
  assert(wwe13::launcher::internal::WriteBinaryFile(paths.settings_file, ini_bytes));
  Settings loaded = LoadSettings(paths);
  assert(loaded.resolution == Resolution::k1440p);
  assert(loaded.frame_rate == FrameRate::kLock30);
  assert(loaded.anti_aliasing == AntiAliasing::kFaster2x);
  assert(loaded.display == DisplayMode::kWindowed);
  assert(loaded.gpu_id == "10DE:2684");
  assert(wwe13::launcher::internal::PathToUtf8(loaded.game_folder) == "C:/Games/Roster-\xC3\xA9");
  assert(loaded.auto_start && !loaded.auto_backup && loaded.explicit_choice);
  assert(SaveSettings(paths, loaded).ok);
  std::vector<uint8_t> saved_bytes;
  assert(wwe13::launcher::internal::ReadBinaryFile(paths.settings_file, saved_bytes));
  assert(saved_bytes.size() >= 2 && saved_bytes[0] == 0xFF && saved_bytes[1] == 0xFE);
  std::string saved_text;
  assert(wwe13::launcher::internal::ReadTextFile(paths.settings_file, saved_text));
  assert(saved_text.find("schema=7") != std::string::npos);
  assert(saved_text.find("unknown_key=keep-this") != std::string::npos);
  assert(saved_text.find("gpu_name=Old GPU") != std::string::npos);
  assert(saved_text.find("[Other]") != std::string::npos && saved_text.find("keep=also-this") != std::string::npos);

  Paths legacy_paths = MakePaths(directory / "legacy");
  fs::create_directories(legacy_paths.exe_dir);
  const auto legacy_bytes = wwe13::launcher::internal::Utf8ToUtf16LeBytes(
      "[Settings]\r\nschema=2\r\ninternal_resolution=576p\r\nframe_rate=classic\r\n"
      "display=fullscreen\r\ngpu=1\r\n");
  assert(wwe13::launcher::internal::WriteBinaryFile(legacy_paths.settings_file, legacy_bytes));
  const Settings legacy = LoadSettings(legacy_paths);
  assert(legacy.resolution == Resolution::k576p && legacy.explicit_choice);
  assert(legacy.frame_rate == FrameRate::kClassic && legacy.gpu_id.empty());

  Paths invalid_utf8_paths = MakePaths(directory / "invalid-utf8");
  fs::create_directories(invalid_utf8_paths.exe_dir);
  const std::string invalid_ini = "[Settings]\nschema=7\ngame_folder=bad-\xC3\nauto_backup=0\n";
  assert(wwe13::launcher::internal::WriteBinaryFile(invalid_utf8_paths.settings_file,
                                                     invalid_ini.data(), invalid_ini.size()));
  const Settings invalid_utf8 = LoadSettings(invalid_utf8_paths);
  assert(invalid_utf8.game_folder == invalid_utf8_paths.default_game_folder);
  assert(!invalid_utf8.auto_backup);

  Paths resolution_paths = MakePaths(directory / "1080");
  fs::create_directories(resolution_paths.exe_dir);
  Settings resolution_settings;
  resolution_settings.resolution = Resolution::k1080p;
  resolution_settings.explicit_choice = true;
  assert(SaveSettings(resolution_paths, resolution_settings).ok);
  assert(LoadSettings(resolution_paths).resolution == Resolution::k1080p);
  const Settings defaults = LoadSettings(resolution_paths);
  assert(!defaults.stretch_to_fill && defaults.sync_to_display);
  resolution_settings.stretch_to_fill = true;
  resolution_settings.sync_to_display = false;
  assert(SaveSettings(resolution_paths, resolution_settings).ok);
  const Settings screen = LoadSettings(resolution_paths);
  assert(screen.stretch_to_fill && !screen.sync_to_display);
  std::cout << "PASS settings UTF-16LE schema-7 round-trip, unknown keys, schema-2 migration, "
               "1080p and screen options persistence\n";
}

const std::string* EnvironmentValue(const LaunchPlan& plan, const std::string& name) {
  for (const auto& [key, value] : plan.environment) if (key == name) return &value;
  return nullptr;
}

void TestLaunchPlan(const fs::path& root) {
  Paths paths = MakePaths(root / "launch");
  fs::create_directories(paths.exe_dir);
  const std::vector<GpuInfo> gpus = {{"10DE:2684", "Discrete", false, 0},
                                     {"1002:164E", "Integrated", true, 1}};
  const std::vector<Resolution> resolutions = {Resolution::k480p, Resolution::k576p,
                                               Resolution::k720p, Resolution::k1080p,
                                               Resolution::k1440p};
  const std::vector<FrameRate> frame_rates = {FrameRate::kClassic, FrameRate::kKeep60,
                                              FrameRate::kLock30};
  for (Resolution resolution : resolutions) {
    for (FrameRate frame_rate : frame_rates) {
      for (AntiAliasing aa : {AntiAliasing::kOriginal4x, AntiAliasing::kFaster2x}) {
        Settings settings;
        settings.resolution = resolution;
        settings.frame_rate = frame_rate;
        settings.anti_aliasing = aa;
        settings.display = DisplayMode::kFullscreen;
        settings.gpu_id = "10DE:2684";
        settings.game_folder = root / "launch" / "WWE 13";
        settings.explicit_choice = true;
        const LaunchPlan plan = BuildLaunchPlan(paths, settings, gpus);
        assert(plan.executable == paths.game_exe);
        assert(plan.working_directory == paths.exe_dir);
        const std::vector<std::string> fixed = {
            wwe13::launcher::internal::PathToUtf8(settings.game_folder),
            "--async_shader_compilation=false", "--vulkan_async_skip_incomplete_frames=false",
            "--fullscreen=true", "--vulkan_allow_present_mode_immediate=false",
            "--ignore_offset_for_ranged_allocations=true", "--log_verbose=false", "--mnk_mode=true"};
        assert(plan.arguments.size() >= fixed.size() + 4);
        for (size_t index = 0; index < fixed.size(); ++index) assert(plan.arguments[index] == fixed[index]);
        assert(plan.arguments[8].starts_with("--log_file="));
        const fs::path log_path = wwe13::launcher::internal::PathFromUtf8(plan.arguments[8].substr(11));
        assert(log_path.parent_path().lexically_normal() == paths.logs_dir.lexically_normal());
        assert(wwe13::launcher::internal::PathToUtf8(log_path.filename()).starts_with("wwe13-"));
        assert(plan.arguments[9] == "--user_data_root=" + wwe13::launcher::internal::PathToUtf8(paths.userdata_dir));
        assert(plan.arguments[10] == "--debug_ui=false");
        assert(plan.arguments[11] == (resolution == Resolution::k1080p
                                          ? "--resolution=1080p" : "--resolution=720p"));
        size_t next = 12;
        if (resolution == Resolution::k1440p) assert(plan.arguments[next++] == "--resolution_scale=2");
        assert(plan.arguments[next++] == "--vulkan_device_id=10DE:2684");
        assert(next == plan.arguments.size());
        assert(EnvironmentValue(plan, "WWE13_F24_PIXEL_RATE") && *EnvironmentValue(plan, "WWE13_F24_PIXEL_RATE") == "1");
        const std::string* internal_res = EnvironmentValue(plan, "WWE13_INTERNAL_RES");
        if (resolution == Resolution::k480p) assert(internal_res && *internal_res == "480");
        else if (resolution == Resolution::k576p) assert(internal_res && *internal_res == "576");
        else if (resolution == Resolution::k1080p) assert(internal_res && *internal_res == "1080");
        else assert(internal_res && internal_res->empty());
        const std::string* scene_aa = EnvironmentValue(plan, "WWE13_SCENE_AA");
        assert(scene_aa && *scene_aa == (aa == AntiAliasing::kFaster2x ? "2x" : ""));
        assert((EnvironmentValue(plan, "WWE13_KEEP_60") != nullptr) == (frame_rate == FrameRate::kKeep60));
        assert((EnvironmentValue(plan, "WWE13_LOCK_30") != nullptr) == (frame_rate == FrameRate::kLock30));
        assert(EnvironmentValue(plan, "WWE13_HOST_VSYNC") && *EnvironmentValue(plan, "WWE13_HOST_VSYNC") == "1");
      }
    }
  }
  Settings screen_options;
  screen_options.gpu_id = "10DE:2684";
  screen_options.stretch_to_fill = true;
  screen_options.sync_to_display = false;
  const LaunchPlan screen_plan = BuildLaunchPlan(paths, screen_options, gpus);
  assert(screen_plan.arguments.back() == "--present_letterbox=false");
  assert(EnvironmentValue(screen_plan, "WWE13_HOST_VSYNC") &&
         *EnvironmentValue(screen_plan, "WWE13_HOST_VSYNC") == "0");
  Settings automatic;
  automatic.gpu_id = "1002:164E";
  const LaunchPlan integrated = BuildLaunchPlan(paths, automatic, gpus);
  assert(EnvironmentValue(integrated, "WWE13_INTERNAL_RES") &&
         *EnvironmentValue(integrated, "WWE13_INTERNAL_RES") == "480");
  assert(EnvironmentValue(integrated, "WWE13_LOCK_30") &&
         *EnvironmentValue(integrated, "WWE13_LOCK_30") == "1");
  std::cout << "PASS launch plan 480p/576p/720p/1080p/1440p x classic/keep60/lock30 x 4x/2x (30 cases)\n";
}

void TestGameChecksAndSearch(const fs::path& root, const fs::path& data) {
  Paths paths = MakePaths(root / "game-checks");
  fs::create_directories(paths.exe_dir);
  const fs::path ready_folder = data / "tu-folder-min";
  const fs::path base_only = data / "base-only-min";
  const GameFilesStatus ready = CheckGameFolder(ready_folder, paths);
  assert(ready.base_game == FileState::kFound && ready.title_update == FileState::kFound && ready.ready());
  const GameFilesStatus no_tu = CheckGameFolder(base_only, paths);
  assert(no_tu.base_game == FileState::kFound && no_tu.title_update == FileState::kMissing && !no_tu.ready());
  const fs::path empty = root / "empty-game-folder";
  fs::create_directories(empty);
  const GameFilesStatus missing = CheckGameFolder(empty, paths);
  assert(missing.base_game == FileState::kMissing && missing.title_update == FileState::kMissing);

#ifndef _WIN32
  const fs::path search_root = root / "search-root";
  fs::create_directories(search_root);
  const fs::path symlink = search_root / "linked-ready-game";
  std::error_code error;
  fs::create_directory_symlink(ready_folder, symlink, error);
  assert(!error);
  Paths search_paths = MakePaths(search_root);
  CancelFlag cancel{false};
  const auto found = FindGameFiles(search_paths,
      [&](uint64_t, uint64_t, const std::string& label) {
        if (fs::path(label) == symlink) cancel.store(true);
      }, cancel);
  assert(!found.empty());
  assert(found.front().folder == symlink && found.front().status.ready());
#endif
  std::cout << "PASS game folder title/TU validation (ready, missing TU, empty) and symlink search\n";
}

void TestBackups(const fs::path& root) {
  Paths fresh_paths = MakePaths(root / "fresh-install");
  fs::create_directories(fresh_paths.exe_dir);
  const Result empty_automatic = BackupSaves(fresh_paths, true, nullptr);
  assert(empty_automatic.ok && !fs::exists(fresh_paths.backups_dir));
  const Result empty_manual = BackupSaves(fresh_paths, false, nullptr);
  assert(!empty_manual.ok && empty_manual.error == "No saved game data was found to back up.");

  Paths paths = MakePaths(root / "saves");
  const fs::path save = paths.userdata_dir / "B13EBABEBABEBABE" / "545108B4" / "SaveData.Dat";
  fs::create_directories(save.parent_path());
  fs::create_directories(paths.exe_dir);
  const std::string original = "original-save-data";
  assert(wwe13::launcher::internal::WriteBinaryFile(save, original.data(), original.size()));
  std::vector<uint8_t> read_back;
  assert(fs::is_regular_file(save));
  assert(wwe13::launcher::internal::ReadBinaryFile(save, read_back) && read_back.size() == original.size());
  const fs::path zip_probe = root / "zip-probe.zip";
  internal::ZipEntry probe_entry{"userdata/B13EBABEBABEBABE/545108B4/SaveData.Dat", read_back};
  assert(internal::CreateZip(zip_probe, {probe_entry}));
  internal::ZipReader probe_zip;
  assert(probe_zip.Open(zip_probe) && probe_zip.ContainsSaveData());
  Settings settings;
  settings.game_folder = paths.default_game_folder;
  assert(SaveSettings(paths, settings).ok);
  BackupInfo manual;
  assert(BackupSaves(paths, false, &manual).ok && !manual.automatic);
  const std::string changed = "changed-save-data";
  assert(wwe13::launcher::internal::WriteBinaryFile(save, changed.data(), changed.size()));
  assert(RestoreBackup(paths, manual.file).ok);
  std::string restored;
  assert(wwe13::launcher::internal::ReadTextFile(save, restored));
  assert(restored == original);

  for (int index = 0; index < 6; ++index) assert(BackupSaves(paths, true, nullptr).ok);
  const auto backups = ListBackups(paths);
  size_t automatic_count = 0;
  for (const auto& backup : backups) if (backup.automatic) ++automatic_count;
  assert(automatic_count == 5);

  const fs::path external = root / "external-save.zip";
  const std::string imported_data = "imported-save-data";
  internal::ZipEntry entry{"SaveData.Dat", std::vector<uint8_t>(imported_data.begin(), imported_data.end())};
  assert(internal::CreateZip(external, {entry}));
  assert(ImportBackup(paths, external).ok);
  fs::path imported;
  for (const auto& backup : ListBackups(paths)) {
    if (wwe13::launcher::internal::PathToUtf8(backup.file.filename()).find("wwe13-saves-import-") == 0) imported = backup.file;
  }
  assert(!imported.empty());
  assert(RestoreBackup(paths, imported).ok);
  assert(wwe13::launcher::internal::ReadTextFile(save, restored));
  assert(restored == imported_data);
  std::cout << "PASS save backup/restore, imported SaveData.Dat, and automatic retention (newest 5)\n";
}

void TestMusic(const fs::path& root) {
  Paths paths = MakePaths(root / "music");
  const fs::path input = root / "short-test.wav";
  WriteShortWav(input);
  const fs::path unsupported = root / "notes.txt";
  {
    std::ofstream out(unsupported);
    out << "not audio";
  }
  std::vector<std::string> skipped;
  assert(AddSongs(paths, {unsupported, input}, &skipped).ok);
  assert(skipped.size() == 1 && skipped.front().find("Only MP3, OGG") != std::string::npos);
  const auto songs = ListSongs(paths);
  assert(songs.size() == 1 && songs.front().format == "WAV" && songs.front().title == "short-test");
  assert(std::abs(songs.front().seconds - 0.25) < 0.01);
  assert(RemoveSong(paths, songs.front().file).ok);
  assert(ListSongs(paths).empty());
  std::cout << "PASS music add/list/remove and WAV duration (0.25 s)\n";
}

void TestBugReport(const fs::path& root) {
  Paths paths = MakePaths(root / "bug-report");
  fs::create_directories(paths.logs_dir);
  fs::create_directories(paths.exe_dir);
  for (int index = 0; index < 4; ++index) {
    const fs::path log = paths.logs_dir / ("game-" + std::to_string(index) + ".log");
    std::ofstream output(log);
    output << "log " << index;
    output.close();
    fs::last_write_time(log, fs::file_time_type::clock::now() - std::chrono::seconds(20 - index));
  }
  // An older freeze-logger exit snapshot must still be included.
  const fs::path snapshot = paths.logs_dir / "wwe13-exit-20261008-054030.txt";
  {
    std::ofstream output(snapshot);
    output << "WWE 13 exit snapshot";
  }
  fs::last_write_time(snapshot, fs::file_time_type::clock::now() - std::chrono::seconds(60));
  Settings settings;
  settings.game_folder = paths.default_game_folder;
  assert(SaveSettings(paths, settings).ok);
  fs::path report;
  assert(SaveBugReport(paths, &report).ok);
  assert(report.parent_path() == paths.exe_dir && fs::is_regular_file(report));
  wwe13::launcher::internal::ZipReader zip;
  assert(zip.Open(report));
  bool newest_seen = false, old_seen = false, ini_seen = false, gpu_seen = false, system_seen = false;
  bool snapshot_seen = false;
  for (size_t index = 0; index < zip.Count(); ++index) {
    mz_zip_archive_file_stat stat{};
    assert(zip.Stat(index, stat));
    const std::string name = stat.m_filename;
    if (name == "logs/game-3.log") newest_seen = true;
    if (name == "logs/game-0.log") old_seen = true;
    if (name == "logs/wwe13-exit-20261008-054030.txt") snapshot_seen = true;
    if (name == "wwe13-enhanced.ini") ini_seen = true;
    if (name == "gpu-list.txt") gpu_seen = true;
    if (name == "system.txt") system_seen = true;
  }
  assert(newest_seen && !old_seen && snapshot_seen && ini_seen && gpu_seen && system_seen);
  std::cout << "PASS bug report ZIP includes newest three logs, an older freeze-logger exit snapshot, INI, GPU "
               "list, and system summary\n";
}

void TestGpus() {
  const auto gpus = ListGpus();
#ifndef _WIN32
  assert(gpus.size() == 3);
#endif
  for (const auto& gpu : gpus) {
    assert(!gpu.id.empty() && !gpu.name.empty() && gpu.vulkan_index >= 0);
    std::cout << "GPU " << gpu.vulkan_index << ": " << gpu.name << " (" << gpu.id << ")\n";
  }
  const Recommendation integrated = RecommendedSettings({{"1002:164E", "Integrated", true, 0}});
  assert(integrated.settings.resolution == Resolution::k480p);
  assert(integrated.settings.frame_rate == FrameRate::kLock30);
  const Recommendation discrete = RecommendedSettings({{"10DE:2684", "Discrete", false, 0}});
  assert(discrete.settings.resolution == Resolution::k720p);
  assert(discrete.settings.frame_rate == FrameRate::kClassic);
  std::cout << "PASS Vulkan filtering/list and integrated/discrete recommendations (" << gpus.size() << " listed)\n";
}

}  // namespace

std::string ReadAll(const fs::path& path) {
  std::ifstream input(path, std::ios::binary);
  return std::string(std::istreambuf_iterator<char>(input), std::istreambuf_iterator<char>());
}

void WriteAll(const fs::path& path, const std::string& text) {
  std::ofstream output(path, std::ios::binary);
  output << text;
}

void TestKeyboardControls(const fs::path& root) {
  const fs::path directory = root / "controls";
  fs::create_directories(directory);
  Paths paths = MakePaths(directory);
  const fs::path toml = directory / "wwe13.toml";
  assert(KeyBindings().size() == 24);
  assert(IsSupportedKeyName("Space") && IsSupportedKeyName("NumpadEnter") && IsSupportedKeyName("RMB"));
  assert(!IsSupportedKeyName("") && !IsSupportedKeyName("space") && !IsSupportedKeyName("Win"));

  // Defaults are the modern layout and contain no duplicate.
  KeyboardControls controls = LoadKeyboardControls(paths);
  assert(controls.keys[0] == "L" && controls.keys[1] == "K" && controls.keys[2] == "J" && controls.keys[3] == "Space");
  assert(controls.keys[5] == "1" && controls.keys[23] == "Escape");
  for (bool duplicate : DuplicateKeyBindings(controls)) assert(!duplicate);

  // No file: EnsureKeyboardDefaults writes all 24 rows (the game's built-in keys differ), and is a no-op afterwards.
  assert(EnsureKeyboardDefaults(paths).ok && fs::exists(toml));
  const std::string first = ReadAll(toml);
  assert(first.find("keybind_a = \"L\"\n") != std::string::npos);
  assert(first.find("keybind_right_trigger = \"1\"\n") != std::string::npos);
  size_t rows = 0;
  for (size_t at = first.find("keybind_"); at != std::string::npos; at = first.find("keybind_", at + 1)) ++rows;
  assert(rows == 24);
  assert(EnsureKeyboardDefaults(paths).ok && ReadAll(toml) == first);
  KeyboardControls loaded = LoadKeyboardControls(paths);
  for (bool present : loaded.present) assert(present);

  // Existing settings: other lines/tables/CRLF are kept, the player's own row is kept, missing rows go to the root table.
  WriteAll(toml, "# my settings\r\nresolution_scale = 2\r\nkeybind_b = \"Z\" # B\r\n\r\n[GPU]\r\nvsync = true\r\n");
  assert(EnsureKeyboardDefaults(paths).ok);
  const std::string merged = ReadAll(toml);
  assert(merged.rfind("# my settings\r\nresolution_scale = 2\r\nkeybind_b = \"Z\" # B\r\n\r\nkeybind_a = \"L\"\r\n", 0) == 0);
  assert(merged.find("[GPU]\r\nvsync = true\r\n") == merged.size() - std::string("[GPU]\r\nvsync = true\r\n").size());
  assert(merged.find("keybind_b = \"K\"") == std::string::npos);
  assert(merged.find("keybind_start = \"Escape\"\r\n[GPU]") != std::string::npos);

  // An older file whose own key clashes with a new default (B on Shift = new run key) is left untouched.
  const std::string clash = "keybind_b = \"Shift\"\n";
  WriteAll(directory / "clash.toml", clash);
  {
    Paths clash_paths = paths;
    fs::create_directories(directory / "clash");
    clash_paths.exe_dir = directory / "clash";
    clash_paths.game_exe = directory / "clash" / "wwe13";
    WriteAll(directory / "clash" / "wwe13.toml", clash);
    assert(EnsureKeyboardDefaults(clash_paths).ok && ReadAll(directory / "clash" / "wwe13.toml") == clash);
  }

  // Changing a key edits that line in place (comment kept).
  KeyboardControls edit = LoadKeyboardControls(paths);
  assert(edit.keys[1] == "Z");
  edit.keys[1] = "NumpadEnter";
  edit.modified[1] = true;
  assert(SaveKeyboardControls(paths, edit).ok);
  assert(ReadAll(toml).find("keybind_b = \"NumpadEnter\" # B\r\n") != std::string::npos);
  assert(LoadKeyboardControls(paths).keys[1] == "NumpadEnter");

  // Duplicates (NumpadEnter and Return are the same key for the game) are refused and the file is unchanged.
  const std::string before = ReadAll(toml);
  KeyboardControls duplicate = LoadKeyboardControls(paths);
  duplicate.keys[2] = "Return";
  duplicate.modified[2] = true;
  const std::vector<bool> flags = DuplicateKeyBindings(duplicate);
  assert(flags[1] && flags[2] && !flags[0]);
  assert(!SaveKeyboardControls(paths, duplicate).ok && ReadAll(toml) == before);

  // Unsupported names are refused; a damaged file loads as defaults instead of failing.
  KeyboardControls bad = LoadKeyboardControls(paths);
  bad.keys[3] = "NotAKey";
  bad.modified[3] = true;
  assert(!SaveKeyboardControls(paths, bad).ok && ReadAll(toml) == before);
  WriteAll(toml, std::string("\xFF\xFE\x00garbage = = \"\n", 16));
  assert(LoadKeyboardControls(paths).keys[0] == "L");
  std::cout << "PASS keyboard controls: modern defaults, first-start file, merge into existing settings, in-place "
               "edit, duplicates, unsupported keys, damaged file\n";
}

void TestGameLanguage(const fs::path& root) {
  const fs::path directory = root / "language";
  fs::create_directories(directory);
  const Paths paths = MakePaths(directory);
  const fs::path toml = directory / "wwe13.toml";

  // Absent file: English, nothing present. Choosing English with no line writes nothing at all.
  assert(!fs::exists(toml));
  GameLanguage language = LoadGameLanguage(paths);
  assert(language.id == 1 && !language.present);
  assert(SaveGameLanguage(paths, 1).ok && !fs::exists(toml));

  // Absent file + German: the file is created with just the one line.
  assert(SaveGameLanguage(paths, 3).ok && ReadAll(toml) == "user_language = 3\n");
  language = LoadGameLanguage(paths);
  assert(language.id == 3 && language.present);

  // Existing file without the line (CRLF, keybinds, a table): inserted before the first [table], rest byte-identical.
  const std::string other = "# my settings\r\nkeybind_a = \"L\" # A\r\nresolution_scale = 2\r\n\r\n[GPU]\r\nvsync = true\r\n";
  WriteAll(toml, other);
  assert(!LoadGameLanguage(paths).present);
  assert(SaveGameLanguage(paths, 4).ok);
  assert(ReadAll(toml) ==
         "# my settings\r\nkeybind_a = \"L\" # A\r\nresolution_scale = 2\r\n\r\nuser_language = 4\r\n[GPU]\r\nvsync = true\r\n");
  assert(LoadGameLanguage(paths).id == 4);
  // English with no existing line leaves the file untouched.
  WriteAll(toml, other);
  assert(SaveGameLanguage(paths, 1).ok && ReadAll(toml) == other);

  // File with no table and no trailing newline: a line break is added first.
  WriteAll(toml, "keybind_b = \"K\"");
  assert(SaveGameLanguage(paths, 5).ok && ReadAll(toml) == "keybind_b = \"K\"\nuser_language = 5\n");

  // Existing line: replaced in place (spacing and comment kept), keybinds and other lines untouched; English writes 1.
  WriteAll(toml, "keybind_a = \"L\"\nuser_language   =   3   # menus\nkeybind_b = \"K\"\n[GPU]\nuser_language = 9\n");
  assert(LoadGameLanguage(paths).id == 3);
  assert(SaveGameLanguage(paths, 6).ok);
  assert(ReadAll(toml) ==
         "keybind_a = \"L\"\nuser_language   =   6   # menus\nkeybind_b = \"K\"\n[GPU]\nuser_language = 9\n");
  assert(SaveGameLanguage(paths, 1).ok && LoadGameLanguage(paths).id == 1 && LoadGameLanguage(paths).present);
  assert(ReadAll(toml).find("user_language   =   1   # menus\n") != std::string::npos);

  // Unknown values (2, 7) are reported as they are and never rewritten unless the caller saves a new choice.
  WriteAll(toml, "user_language = 7\nkeybind_a = \"L\"\n");
  language = LoadGameLanguage(paths);
  assert(language.id == 7 && language.present);
  assert(LoadKeyboardControls(paths).keys[0] == "L");
  WriteAll(toml, "user_language = 2\n");
  assert(LoadGameLanguage(paths).id == 2);
  assert(SaveGameLanguage(paths, 2).ok && ReadAll(toml) == "user_language = 2\n");

  // Unreadable value (quoted text): treated as absent/English; the line is only changed when the user picks.
  WriteAll(toml, "user_language = \"german\"\n");
  language = LoadGameLanguage(paths);
  assert(language.id == 1 && !language.present);
  assert(SaveGameLanguage(paths, 3).ok && ReadAll(toml) == "user_language = 3\n");

  // Saving the language never disturbs keybinds, and saving keybinds never disturbs the language.
  WriteAll(toml, "user_language = 4\n");
  assert(EnsureKeyboardDefaults(paths).ok);
  assert(LoadGameLanguage(paths).id == 4 && LoadKeyboardControls(paths).keys[0] == "L");
  assert(SaveGameLanguage(paths, 5).ok && LoadKeyboardControls(paths).keys[1] == "K" && LoadGameLanguage(paths).id == 5);
  std::cout << "PASS game language: absent, insert, replace in place, byte preservation, unknown values, keybinds\n";
}

int main() {
  const fs::path output = fs::path(WWE13_LAUNCHER_TESTDATA).parent_path() / "core";
  std::error_code error;
  fs::create_directories(output, error);
  assert(!error);
  fs::remove_all(output / "run", error);
  error.clear();
  fs::create_directories(output / "run", error);
  assert(!error);
  const fs::path root = output / "run";
  const fs::path data = WWE13_LAUNCHER_TESTDATA;
  TestSettings(root);
  TestLaunchPlan(root);
  TestGameChecksAndSearch(root, data);
  TestBackups(root);
  TestMusic(root);
  TestBugReport(root);
  TestGpus();
  TestKeyboardControls(root);
  TestGameLanguage(root);
  std::cout << "All core tests passed.\n";
  return 0;
}
